package net.minecraft;

import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.mojang.logging.LogUtils;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.UUID;
import net.minecraft.server.packs.metadata.pack.PackFormat;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.level.storage.DataVersion;
import org.slf4j.Logger;

public class DetectedVersion {
	private static final Logger LOGGER = LogUtils.getLogger();
	public static final WorldVersion BUILT_IN = createBuiltIn(UUID.randomUUID().toString().replaceAll("-", ""), "Development Version");

	public static WorldVersion createBuiltIn(String id, String name) {
		return createBuiltIn(id, name, true);
	}

	public static WorldVersion createBuiltIn(String id, String name, boolean stable) {
		return new WorldVersion.Simple(
			id, name, new DataVersion(4556, "main"), SharedConstants.getProtocolVersion(), PackFormat.of(69, 0), PackFormat.of(88, 0), new Date(), stable
		);
	}

	private static WorldVersion createFromJson(JsonObject json) {
		JsonObject jsonObject = GsonHelper.getAsJsonObject(json, "pack_version");
		return new WorldVersion.Simple(
			GsonHelper.getAsString(json, "id"),
			GsonHelper.getAsString(json, "name"),
			new DataVersion(GsonHelper.getAsInt(json, "world_version"), GsonHelper.getAsString(json, "series_id", "main")),
			GsonHelper.getAsInt(json, "protocol_version"),
			PackFormat.of(GsonHelper.getAsInt(jsonObject, "resource_major"), GsonHelper.getAsInt(jsonObject, "resource_minor")),
			PackFormat.of(GsonHelper.getAsInt(jsonObject, "data_major"), GsonHelper.getAsInt(jsonObject, "data_minor")),
			Date.from(ZonedDateTime.parse(GsonHelper.getAsString(json, "build_time")).toInstant()),
			GsonHelper.getAsBoolean(json, "stable")
		);
	}

	/**
	 * Creates a new instance containing world version data from version.json (or fallback data if necessary).
	 * 
	 * For getting data, use {@link SharedConstants#getCurrentVersion} instead, as that is cached.
	 */
	public static WorldVersion tryDetectVersion() {
		try {
			InputStream inputStream = DetectedVersion.class.getResourceAsStream("/version.json");

			WorldVersion var9;
			label63: {
				WorldVersion var2;
				try {
					if (inputStream == null) {
						LOGGER.warn("Missing version information!");
						var9 = BUILT_IN;
						break label63;
					}

					InputStreamReader inputStreamReader = new InputStreamReader(inputStream);

					try {
						var2 = createFromJson(GsonHelper.parse(inputStreamReader));
					} catch (Throwable var6) {
						try {
							inputStreamReader.close();
						} catch (Throwable var5) {
							var6.addSuppressed(var5);
						}

						throw var6;
					}

					inputStreamReader.close();
				} catch (Throwable var7) {
					if (inputStream != null) {
						try {
							inputStream.close();
						} catch (Throwable var4) {
							var7.addSuppressed(var4);
						}
					}

					throw var7;
				}

				if (inputStream != null) {
					inputStream.close();
				}

				return var2;
			}

			if (inputStream != null) {
				inputStream.close();
			}

			return var9;
		} catch (JsonParseException | IOException var8) {
			throw new IllegalStateException("Game version information is corrupt", var8);
		}
	}
}
