package net.minecraft.world.entity.ai.sensing;

import com.google.common.collect.ImmutableSet;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.Brain;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.memory.NearestVisibleLivingEntities;
import net.minecraft.world.phys.AABB;

public class NearestLivingEntitySensor<T extends LivingEntity> extends Sensor<T> {
	@Override
	protected void doTick(ServerLevel level, T entity) {
		double d = entity.getAttributeValue(Attributes.FOLLOW_RANGE);
		AABB aABB = entity.getBoundingBox().inflate(d, d, d);
		List<LivingEntity> list = level.getEntitiesOfClass(LivingEntity.class, aABB, livingEntity2 -> livingEntity2 != entity && livingEntity2.isAlive());
		list.sort(Comparator.comparingDouble(entity::distanceToSqr));
		Brain<?> brain = entity.getBrain();
		brain.setMemory(MemoryModuleType.NEAREST_LIVING_ENTITIES, list);
		brain.setMemory(MemoryModuleType.NEAREST_VISIBLE_LIVING_ENTITIES, new NearestVisibleLivingEntities(level, entity, list));
	}

	@Override
	public Set<MemoryModuleType<?>> requires() {
		return ImmutableSet.of(MemoryModuleType.NEAREST_LIVING_ENTITIES, MemoryModuleType.NEAREST_VISIBLE_LIVING_ENTITIES);
	}
}
