package net.minecraft.world.entity.ai.behavior;

import com.mojang.datafixers.util.Pair;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.memory.MemoryStatus;

public class GateBehavior<E extends LivingEntity> implements BehaviorControl<E> {
	private final Map<MemoryModuleType<?>, MemoryStatus> entryCondition;
	private final Set<MemoryModuleType<?>> exitErasedMemories;
	private final GateBehavior.OrderPolicy orderPolicy;
	private final GateBehavior.RunningPolicy runningPolicy;
	private final ShufflingList<BehaviorControl<? super E>> behaviors = new ShufflingList<>();
	private Behavior.Status status = Behavior.Status.STOPPED;

	public GateBehavior(
		Map<MemoryModuleType<?>, MemoryStatus> entryCondition,
		Set<MemoryModuleType<?>> exitErasedMemories,
		GateBehavior.OrderPolicy orderPolicy,
		GateBehavior.RunningPolicy runningPolicy,
		List<Pair<? extends BehaviorControl<? super E>, Integer>> durations
	) {
		this.entryCondition = entryCondition;
		this.exitErasedMemories = exitErasedMemories;
		this.orderPolicy = orderPolicy;
		this.runningPolicy = runningPolicy;
		durations.forEach(pair -> this.behaviors.add((BehaviorControl)pair.getFirst(), (Integer)pair.getSecond()));
	}

	@Override
	public Behavior.Status getStatus() {
		return this.status;
	}

	private boolean hasRequiredMemories(E entity) {
		for (Entry<MemoryModuleType<?>, MemoryStatus> entry : this.entryCondition.entrySet()) {
			MemoryModuleType<?> memoryModuleType = (MemoryModuleType<?>)entry.getKey();
			MemoryStatus memoryStatus = (MemoryStatus)entry.getValue();
			if (!entity.getBrain().checkMemory(memoryModuleType, memoryStatus)) {
				return false;
			}
		}

		return true;
	}

	@Override
	public final boolean tryStart(ServerLevel level, E entity, long gameTime) {
		if (this.hasRequiredMemories(entity)) {
			this.status = Behavior.Status.RUNNING;
			this.orderPolicy.apply(this.behaviors);
			this.runningPolicy.apply(this.behaviors.stream(), level, entity, gameTime);
			return true;
		} else {
			return false;
		}
	}

	@Override
	public final void tickOrStop(ServerLevel level, E entity, long gameTime) {
		this.behaviors
			.stream()
			.filter(behaviorControl -> behaviorControl.getStatus() == Behavior.Status.RUNNING)
			.forEach(behaviorControl -> behaviorControl.tickOrStop(level, entity, gameTime));
		if (this.behaviors.stream().noneMatch(behaviorControl -> behaviorControl.getStatus() == Behavior.Status.RUNNING)) {
			this.doStop(level, entity, gameTime);
		}
	}

	@Override
	public final void doStop(ServerLevel level, E entity, long gameTime) {
		this.status = Behavior.Status.STOPPED;
		this.behaviors
			.stream()
			.filter(behaviorControl -> behaviorControl.getStatus() == Behavior.Status.RUNNING)
			.forEach(behaviorControl -> behaviorControl.doStop(level, entity, gameTime));
		this.exitErasedMemories.forEach(entity.getBrain()::eraseMemory);
	}

	@Override
	public String debugString() {
		return this.getClass().getSimpleName();
	}

	public String toString() {
		Set<? extends BehaviorControl<? super E>> set = (Set<? extends BehaviorControl<? super E>>)this.behaviors
			.stream()
			.filter(behaviorControl -> behaviorControl.getStatus() == Behavior.Status.RUNNING)
			.collect(Collectors.toSet());
		return "(" + this.getClass().getSimpleName() + "): " + set;
	}

	public static enum OrderPolicy {
		ORDERED(shufflingList -> {}),
		SHUFFLED(ShufflingList::shuffle);

		private final Consumer<ShufflingList<?>> consumer;

		private OrderPolicy(final Consumer<ShufflingList<?>> consumer) {
			this.consumer = consumer;
		}

		public void apply(ShufflingList<?> list) {
			this.consumer.accept(list);
		}
	}

	public static enum RunningPolicy {
		RUN_ONE {
			@Override
			public <E extends LivingEntity> void apply(Stream<BehaviorControl<? super E>> behaviors, ServerLevel level, E owner, long gameTime) {
				behaviors.filter(behaviorControl -> behaviorControl.getStatus() == Behavior.Status.STOPPED)
					.filter(behaviorControl -> behaviorControl.tryStart(level, owner, gameTime))
					.findFirst();
			}
		},
		TRY_ALL {
			@Override
			public <E extends LivingEntity> void apply(Stream<BehaviorControl<? super E>> behaviors, ServerLevel level, E owner, long gameTime) {
				behaviors.filter(behaviorControl -> behaviorControl.getStatus() == Behavior.Status.STOPPED)
					.forEach(behaviorControl -> behaviorControl.tryStart(level, owner, gameTime));
			}
		};

		public abstract <E extends LivingEntity> void apply(Stream<BehaviorControl<? super E>> behaviors, ServerLevel level, E owner, long gameTime);
	}
}
