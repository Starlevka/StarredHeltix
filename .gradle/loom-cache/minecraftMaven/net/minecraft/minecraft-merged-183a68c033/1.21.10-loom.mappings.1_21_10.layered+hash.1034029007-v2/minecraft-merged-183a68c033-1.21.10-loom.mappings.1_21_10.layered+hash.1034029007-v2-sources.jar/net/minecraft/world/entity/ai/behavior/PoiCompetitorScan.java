package net.minecraft.world.entity.ai.behavior;

import java.util.List;
import java.util.Optional;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.Holder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.behavior.declarative.BehaviorBuilder;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.village.poi.PoiType;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;

public class PoiCompetitorScan {
	public static BehaviorControl<Villager> create() {
		return BehaviorBuilder.create(
			instance -> instance.group(instance.present(MemoryModuleType.JOB_SITE), instance.present(MemoryModuleType.NEAREST_LIVING_ENTITIES))
				.apply(
					instance,
					(memoryAccessor, memoryAccessor2) -> (serverLevel, villager, l) -> {
						GlobalPos globalPos = instance.get(memoryAccessor);
						serverLevel.getPoiManager()
							.getType(globalPos.pos())
							.ifPresent(
								holder -> instance.<List>get(memoryAccessor2)
									.stream()
									.filter(livingEntity -> livingEntity instanceof Villager && livingEntity != villager)
									.map(livingEntity -> (Villager)livingEntity)
									.filter(LivingEntity::isAlive)
									.filter(villagerxx -> competesForSameJobsite(globalPos, holder, villagerxx))
									.reduce(villager, PoiCompetitorScan::selectWinner)
							);
						return true;
					}
				)
		);
	}

	private static Villager selectWinner(Villager villagerA, Villager villagerB) {
		Villager villager;
		Villager villager2;
		if (villagerA.getVillagerXp() > villagerB.getVillagerXp()) {
			villager = villagerA;
			villager2 = villagerB;
		} else {
			villager = villagerB;
			villager2 = villagerA;
		}

		villager2.getBrain().eraseMemory(MemoryModuleType.JOB_SITE);
		return villager;
	}

	private static boolean competesForSameJobsite(GlobalPos jobSitePos, Holder<PoiType> poiType, Villager villager) {
		Optional<GlobalPos> optional = villager.getBrain().getMemory(MemoryModuleType.JOB_SITE);
		return optional.isPresent() && jobSitePos.equals(optional.get()) && hasMatchingProfession(poiType, villager.getVillagerData().profession());
	}

	private static boolean hasMatchingProfession(Holder<PoiType> poiType, Holder<VillagerProfession> profession) {
		return profession.value().heldJobSite().test(poiType);
	}
}
