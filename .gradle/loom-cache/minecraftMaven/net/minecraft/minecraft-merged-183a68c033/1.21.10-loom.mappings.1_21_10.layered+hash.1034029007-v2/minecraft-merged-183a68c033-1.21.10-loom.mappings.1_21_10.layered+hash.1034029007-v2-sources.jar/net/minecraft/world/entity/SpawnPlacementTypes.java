package net.minecraft.world.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.NaturalSpawner;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.pathfinder.PathComputationType;
import org.jetbrains.annotations.Nullable;

public interface SpawnPlacementTypes {
	SpawnPlacementType NO_RESTRICTIONS = (levelReader, blockPos, entityType) -> true;
	SpawnPlacementType IN_WATER = (levelReader, blockPos, entityType) -> {
		if (entityType != null && levelReader.getWorldBorder().isWithinBounds(blockPos)) {
			BlockPos blockPos2 = blockPos.above();
			return levelReader.getFluidState(blockPos).is(FluidTags.WATER) && !levelReader.getBlockState(blockPos2).isRedstoneConductor(levelReader, blockPos2);
		} else {
			return false;
		}
	};
	SpawnPlacementType IN_LAVA = (levelReader, blockPos, entityType) -> entityType != null && levelReader.getWorldBorder().isWithinBounds(blockPos)
		? levelReader.getFluidState(blockPos).is(FluidTags.LAVA)
		: false;
	SpawnPlacementType ON_GROUND = new SpawnPlacementType() {
		@Override
		public boolean isSpawnPositionOk(LevelReader levelReader, BlockPos blockPos, @Nullable EntityType<?> entityType) {
			if (entityType != null && levelReader.getWorldBorder().isWithinBounds(blockPos)) {
				BlockPos blockPos2 = blockPos.above();
				BlockPos blockPos3 = blockPos.below();
				BlockState blockState = levelReader.getBlockState(blockPos3);
				return !blockState.isValidSpawn(levelReader, blockPos3, entityType)
					? false
					: this.isValidEmptySpawnBlock(levelReader, blockPos, entityType) && this.isValidEmptySpawnBlock(levelReader, blockPos2, entityType);
			} else {
				return false;
			}
		}

		private boolean isValidEmptySpawnBlock(LevelReader level, BlockPos pos, EntityType<?> entityType) {
			BlockState blockState = level.getBlockState(pos);
			return NaturalSpawner.isValidEmptySpawnBlock(level, pos, blockState, blockState.getFluidState(), entityType);
		}

		@Override
		public BlockPos adjustSpawnPosition(LevelReader level, BlockPos pos) {
			BlockPos blockPos = pos.below();
			return level.getBlockState(blockPos).isPathfindable(PathComputationType.LAND) ? blockPos : pos;
		}
	};
}
