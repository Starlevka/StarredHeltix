package set.starlev.mixin;

import net.minecraft.class_2561;
import net.minecraft.class_634;
import net.minecraft.class_7439;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.features.chat.ChatEventsManager;

@Mixin(class_634.class)
public class ChatReceiveMixin {
    @Inject(method = "handleSystemChat", at = @At("HEAD"), cancellable = true)
    private void onReceiveChat(class_7439 packet, CallbackInfo ci) {
        class_2561 message = packet.comp_763();
        String messageText = message.getString();
        
        if (!set.starlev.features.chat.MessageFilterManager.INSTANCE.shouldAllowMessage(messageText)) {
            ci.cancel();
            return;
        }
        
        ChatEventsManager.INSTANCE.onIncomingMessage(messageText);
    }
}
