package set.starlev.mixin.client;

import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.StarredHeltix;

@Mixin(class_310.class)
public class MinecraftMixin {
    @Shadow
    public class_437 screen;

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        class_437 toOpen = StarredHeltix.Companion.getScreenToOpen();
        if (toOpen != null) {
            StarredHeltix.Companion.setScreenToOpen(null);
            ((class_310)(Object)this).method_1507(toOpen);
        }
        set.starlev.features.chat.AutoReadyNotifier.INSTANCE.tick();
        set.starlev.features.misc.AutoSprint.INSTANCE.tick();
        set.starlev.features.misc.CustomBindManager.INSTANCE.tick();
    }
}
