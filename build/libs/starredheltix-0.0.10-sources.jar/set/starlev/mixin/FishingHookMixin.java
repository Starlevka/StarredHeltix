package set.starlev.mixin;

import net.minecraft.class_2767;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.features.fishing.FishingNotifier;

@Mixin(class_634.class)
public class FishingHookMixin {
    @Inject(method = "handleSoundEvent", at = @At("HEAD"))
    private void onPlaySound(class_2767 packet, CallbackInfo ci) {
        // Check for fishing splash sound
        String soundName = packet.method_11894().comp_349().comp_3319().toString();
        if (soundName.equals("minecraft:entity.fishing_bobber.splash") ||
            soundName.equals("entity.fishing_bobber.splash")) {
            class_310 client = class_310.method_1551();
            if (client.field_1724 != null && client.field_1724.field_7513 != null) {
                FishingNotifier.INSTANCE.onBite();
            }
        }
    }
}
