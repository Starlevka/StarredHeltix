package set.starlev.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import set.starlev.features.foraging.TreeCapCooldown;

@Mixin(class_636.class)
public class TreeCapBlockBreakMixin {
    private static final Logger LOGGER = LoggerFactory.getLogger("StarredHeltix/TreeCapBlockBreakMixin");

    @Inject(method = "destroyBlock", at = @At("HEAD"))
    private void onDestroyBlock(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        class_1937 world = mc.field_1687;
        
        if (player != null && world != null) {
            // Получаем название блока
            String blockName = world.method_8320(pos).method_26204().method_63499();
            
            LOGGER.info("Блок разрушен: {}", blockName);
            
            // Проверяем что это логи (дерево)
            if (isLog(blockName)) {
                LOGGER.info("Обнаружено разрушение лога: {}", blockName);
                TreeCapCooldown.INSTANCE.onLogBreak(blockName);
            } else {
                TreeCapCooldown.INSTANCE.onBlockBreak(blockName);
            }
        }
    }

    private boolean isLog(String blockName) {
        // Проверяем стандартные логи Minecraft и похожие варианты
        return blockName.contains("log") || blockName.contains("wood");
    }
}
