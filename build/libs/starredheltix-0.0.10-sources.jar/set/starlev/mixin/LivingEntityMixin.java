package set.starlev.mixin;

import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.StarredHeltix;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends class_1297 {
    public LivingEntityMixin(class_1299<?> type, class_1937 level) {
        super(type, level);
    }

    @Inject(method = "die", at = @At("HEAD"))
    private void onDeath(class_1282 source, CallbackInfo ci) {
        if (StarredHeltix.Companion.getFeature().getOptimization().getHideDeathAnimation()) {
            this.method_31472();
        }
    }
}
