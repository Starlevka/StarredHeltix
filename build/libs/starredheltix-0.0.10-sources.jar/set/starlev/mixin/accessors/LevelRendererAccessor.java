package set.starlev.mixin.accessors;

import net.minecraft.class_4599;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_761.class)
public interface LevelRendererAccessor {
    @Accessor
    class_4599 getRenderBuffers();
}
