package set.starlev.mixin.accessors;

import net.minecraft.class_269;
import org.spongepowered.asm.mixin.Mixin;

/**
 * TODO: Реализовать accessor для Scoreboard в 1.21.10
 */
@Mixin(class_269.class)
public interface ScoreboardAccessor {
    // ScoreboardEntry не существует в 1.21.10
}
