package set.starlev.mixin;

import net.minecraft.class_332;
import net.minecraft.class_485;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.StarredHeltix;

@Mixin(class_485.class)
public class EffectRenderingInventoryScreenMixin {
    @Inject(method = "renderEffects(Lnet/minecraft/client/gui/GuiGraphics;II)V", at = @At("HEAD"), cancellable = true)
    private void onRenderEffects(class_332 guiGraphics, int mouseX, int mouseY, CallbackInfo ci) {
        if (StarredHeltix.Companion.getFeature().getOptimization().getHideStatusEffects()) {
            ci.cancel();
        }
    }
}
