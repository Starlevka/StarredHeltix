package set.starlev.mixin;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_761;
import net.minecraft.class_7833;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.render.RenderContext;
import set.starlev.render.RenderEvents;

@Mixin(class_761.class)
public class LevelRendererMixin {
    @Shadow @Final private net.minecraft.class_4599 renderBuffers;

    @Inject(method = "renderLevel", at = @At("RETURN"))
    private void onRenderWorld(class_9922 allocator, class_9779 deltaTracker, boolean renderBlockOutline, class_4184 camera, Matrix4f matrix4f, Matrix4f matrix4f2, Matrix4f matrix4f3, GpuBufferSlice gpuBufferSlice, Vector4f vector4f, boolean bl, CallbackInfo ci) {
        class_4587 poseStack = new class_4587();
        
        // Apply camera rotation
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));

        class_4597.class_4598 bufferSource = this.renderBuffers.method_23000();

        // Создаем RenderContext
        RenderContext context = new RenderContext(poseStack, camera, deltaTracker.method_60636(), bufferSource);

        // Вызываем RenderEvents
        RenderEvents.fireWorldRender(context);

        // Также вызываем старый RenderEngine для совместимости
        poseStack.method_22904(-camera.method_19326().field_1352, -camera.method_19326().field_1351, -camera.method_19326().field_1350);
        set.starlev.render.RenderEngine.renderWorld(poseStack, bufferSource, deltaTracker.method_60636());
        bufferSource.method_22993();
    }
}
