package set.starlev.mixin;

import net.minecraft.class_11909;
import net.minecraft.class_332;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starlev.features.chat.ChatCopyFeature;

@Mixin(class_408.class)
public class ChatScreenMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(class_332 graphics, int mouseX, int mouseY, float partialTicks, CallbackInfo ci) {
        try {
            ChatCopyFeature.INSTANCE.handleRender(graphics, mouseX, mouseY);
        } catch (Exception e) {
            System.err.println("Error in ChatCopyFeature.handleRender: " + e);
            e.printStackTrace();
        }
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void onMouseClicked(class_11909 event, boolean doubleClick, CallbackInfoReturnable<Boolean> cir) {
        System.out.println("ChatScreen.mouseClicked called with button=" + event.method_74245() + " at (" + event.comp_4798() + ", " + event.comp_4799() + ") doubleClick=" + doubleClick);
        try {
            if (ChatCopyFeature.INSTANCE.handleMouseClick(event.comp_4798(), event.comp_4799(), event.method_74245())) {
                System.out.println("ChatCopyFeature handled the click");
                cir.setReturnValue(true);
            }
        } catch (Exception e) {
            System.err.println("Error in ChatCopyFeature.handleMouseClick: " + e);
            e.printStackTrace();
        }
    }
}
