package set.starlev.mixin;

import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.StarredHeltix;

@Mixin(class_329.class)
public class GuiMixin {
    @Inject(method = "renderEffects", at = @At("HEAD"), cancellable = true)
    private void onRenderEffects(class_332 guiGraphics, class_9779 deltaTracker, CallbackInfo ci) {
        if (StarredHeltix.Companion.getFeature().getOptimization().getHideStatusEffects()) {
            ci.cancel();
        }
    }
}
