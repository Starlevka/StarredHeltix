package set.starlev.mixin;

import net.minecraft.class_4587;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import set.starlev.features.visual.SwingAnimation;

@Mixin(class_759.class)
public class ItemInHandRendererMixin {

    @ModifyVariable(method = "applyItemArmAttackTransform", at = @At("HEAD"), ordinal = 0, argsOnly = true)
    private float modifyAttackSwingProgress(float swingProgress) {
        if (SwingAnimation.INSTANCE.isSwingSpeedEnabled()) {
            return swingProgress * SwingAnimation.INSTANCE.getSwingSpeed();
        }
        return swingProgress;
    }

    @Redirect(method = "applyItemArmTransform", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(FFF)V", ordinal = 0))
    private void onSwingArmTranslate(class_4587 instance, float x, float y, float z) {
        if (SwingAnimation.INSTANCE.isEnabled()) {
            instance.method_22904(
                x * SwingAnimation.INSTANCE.getSwingX(),
                y * SwingAnimation.INSTANCE.getSwingY(),
                z * SwingAnimation.INSTANCE.getSwingZ()
            );
        } else {
            instance.method_46416(x, y, z);
        }
    }
}
