package set.starlev.utils;

import net.minecraft.class_4604;

public interface IWorldRenderer {
    class_4604 starredheltix$getFrustum();
    void starredheltix$setFrustum(class_4604 frustum);
}
