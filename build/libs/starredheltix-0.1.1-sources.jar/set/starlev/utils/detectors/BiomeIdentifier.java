package set.starlev.utils.detectors;

import net.minecraft.class_2338;

/**
 * Интерфейс для определения биома через Mixin.
 */
public interface BiomeIdentifier {
    /**
     * Получить ID биома по координатам.
     * @param pos Позиция
     * @return ID биома (например, "minecraft:plains")
     */
    String starlev$getBiomeId(class_2338 pos);
}
