package set.starlev.injections.accessors;

import net.minecraft.class_1799;
import net.minecraft.class_329;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_329.class)
public interface GuiAccessor {
    @Accessor("overlayMessageString")
    net.minecraft.class_2561 getOverlayMessageString();

    @Accessor("toolHighlightTimer")
    int getToolHighlightTimer();

    @Accessor("lastToolHighlight")
    class_1799 getLastToolHighlight();

    @Accessor("title")
    net.minecraft.class_2561 getTitle();

    @Accessor("subtitle")
    net.minecraft.class_2561 getSubtitle();

    @Accessor("titleTime")
    int getTitleTime();
}
