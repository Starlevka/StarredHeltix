package set.starlev.injections.accessors;

import net.minecraft.class_1661;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1661.class)
public interface InventoryAccessor {
    @Accessor("selected")
    int getSelectedSlot();
}