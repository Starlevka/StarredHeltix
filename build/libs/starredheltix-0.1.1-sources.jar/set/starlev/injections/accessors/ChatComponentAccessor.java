package set.starlev.injections.accessors;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.List;
import net.minecraft.class_303;
import net.minecraft.class_338;

@Mixin(class_338.class)
public interface ChatComponentAccessor {
    @Accessor("allMessages")
    List<class_303> getAllMessages();

    @Accessor("trimmedMessages")
    List<class_303.class_7590> getTrimmedMessages();

    @Accessor("chatScrollbarPos")
    int getScroll();

    @Invoker("screenToChatX")
    double invokeScreenToChatX(double x);

    @Invoker("screenToChatY")
    double invokeScreenToChatY(double y);
}
