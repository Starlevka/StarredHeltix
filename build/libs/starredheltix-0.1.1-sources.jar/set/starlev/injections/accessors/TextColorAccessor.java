package set.starlev.injections.accessors;

import net.minecraft.class_5251;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_5251.class)
public interface TextColorAccessor {
    @Accessor("name")
    String getName();

    @Accessor("value")
    int getValue();
}
