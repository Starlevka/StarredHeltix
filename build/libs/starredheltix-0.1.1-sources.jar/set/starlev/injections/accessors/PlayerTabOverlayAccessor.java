package set.starlev.injections.accessors;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_355;
import net.minecraft.class_640;

@Mixin(class_355.class)
public interface PlayerTabOverlayAccessor {
    @Accessor("header")
    class_2561 getHeader();

    @Accessor("footer")
    class_2561 getFooter();

    @Invoker("getPlayerInfos")
    List<class_640> invokeGetPlayerInfos();
}
