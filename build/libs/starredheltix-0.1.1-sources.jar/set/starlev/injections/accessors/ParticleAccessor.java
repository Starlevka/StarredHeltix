package set.starlev.injections.accessors;

import net.minecraft.class_703;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_703.class)
public interface ParticleAccessor {
    @Accessor("x")
    double starredheltix$getX();

    @Accessor("y")
    double starredheltix$getY();

    @Accessor("z")
    double starredheltix$getZ();
}
