package set.starlev.injections.mixin.world;

import net.minecraft.class_1959;
import net.minecraft.class_2338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starlev.secret.features.SecretFunFeatures;

@Mixin(class_1959.class)
public class BiomeMixin {
    @Inject(method = "getPrecipitationAt(Lnet/minecraft/core/BlockPos;I)Lnet/minecraft/world/level/biome/Biome$Precipitation;", at = @At("HEAD"), cancellable = true)
    private void onGetPrecipitationAt(class_2338 pos, int seaLevel, CallbackInfoReturnable<class_1959.class_1963> cir) {
        if (SecretFunFeatures.INSTANCE.isSnowEverywhereEnabled()) {
            cir.setReturnValue(class_1959.class_1963.field_9383);
        }
    }

    @Inject(method = "hasPrecipitation()Z", at = @At("HEAD"), cancellable = true)
    private void onHasPrecipitation(CallbackInfoReturnable<Boolean> cir) {
        if (SecretFunFeatures.INSTANCE.isSnowEverywhereEnabled()) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "coldEnoughToSnow(Lnet/minecraft/core/BlockPos;I)Z", at = @At("HEAD"), cancellable = true)
    private void onColdEnoughToSnow(class_2338 pos, int seaLevel, CallbackInfoReturnable<Boolean> cir) {
        if (SecretFunFeatures.INSTANCE.isSnowEverywhereEnabled()) {
            cir.setReturnValue(true);
        }
    }
}
