package set.starlev.injections.mixin.world;

import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_4543;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starlev.StarredHeltix;
import set.starlev.secret.features.SecretFunFeatures;

@Mixin(class_4543.class)
public class BiomeManagerMixin {
    @Inject(method = "getBiome(Lnet/minecraft/core/BlockPos;)Lnet/minecraft/core/Holder;", at = @At("RETURN"), cancellable = true)
    private void onGetBiome(class_2338 pos, CallbackInfoReturnable<class_6880<class_1959>> cir) {
        if (SecretFunFeatures.INSTANCE.isSnowEverywhereEnabled()) {
            class_310 client = class_310.method_1551();
            if (client.field_1687 != null) {
                client.field_1687.method_30349().method_46759(class_7924.field_41236)
                        .flatMap(registry -> registry.method_46746(class_1972.field_35117))
                        .ifPresent(cir::setReturnValue);
            }
        }
    }
}
