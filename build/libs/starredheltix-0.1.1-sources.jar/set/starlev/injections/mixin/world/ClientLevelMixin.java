package set.starlev.injections.mixin.world;

import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starlev.StarredHeltix;
import set.starlev.utils.detectors.BiomeIdentifier;

/**
    * Миксин для ClientLevel для предоставления ID биома и принудительных эффектов.
    */
@Mixin(class_638.class)
public abstract class ClientLevelMixin implements BiomeIdentifier {

    @Inject(method = "addDestroyBlockEffect", at = @At("HEAD"), cancellable = true)
    private void onAddDestroyBlockEffect(class_2338 pos, class_2680 state, CallbackInfo ci) {
        if (StarredHeltix.Companion.getFeature().getOptimization().getVisualOptimizations().getDisableBlockBreakingParticles()) {
            ci.cancel();
        }
    }

    @Inject(method = "addBreakingBlockEffect", at = @At("HEAD"), cancellable = true)
    private void onAddBreakingBlockEffect(class_2338 pos, class_2350 direction, CallbackInfo ci) {
        if (StarredHeltix.Companion.getFeature().getOptimization().getVisualOptimizations().getDisableBlockBreakingParticles()) {
            ci.cancel();
        }
    }
    
    @Override
    public String starlev$getBiomeId(class_2338 pos) {
        if (!((Object)this instanceof class_638)) return "unknown";
        class_638 level = (class_638) (Object) this;
        class_6880<class_1959> biomeHolder = level.method_22385().method_22393(pos);
        return biomeHolder.method_40230()
                .map(key -> key.method_29177().toString())
                .orElse("unknown");
    }
}
