package set.starlev.injections.mixin.chat;

import net.minecraft.class_2561;
import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import set.starlev.features.chat.ChatFormatting;
import set.starlev.secret.config.SecretMenuManager;
import set.starlev.secret.features.SecretFunFeatures;

@Mixin(class_338.class)
public class ChatComponentMixin {
    @ModifyVariable(method = "addMessage(Lnet/minecraft/network/chat/Component;)V", at = @At("HEAD"), argsOnly = true)
    private class_2561 onAddMessageSimple(class_2561 component) {
        return applyStarlev(component);
    }

    @ModifyVariable(method = "addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/GuiMessageTag;)V", at = @At("HEAD"), argsOnly = true)
    private class_2561 onAddMessageFull(class_2561 component) {
        return applyStarlev(component);
    }

    private class_2561 applyStarlev(class_2561 component) {
        if (component == null) return null;
        
        class_2561 processed = component;
        if (SecretMenuManager.INSTANCE.isConfigInitialized()) {
            // В чате эффекты применяются всегда (force=true), если включены в конфиге
            processed = SecretFunFeatures.processComponent(processed, true);
        }
        
        class_2561 finalComp = ChatFormatting.processComponent(processed);
        
        // Отладочный вывод в консоль для проверки работы миксина
        if (finalComp != processed) {
            System.out.println("[StarredHeltix] Chat message formatted: " + finalComp.getString());
        }
        
        return finalComp;
    }
}
