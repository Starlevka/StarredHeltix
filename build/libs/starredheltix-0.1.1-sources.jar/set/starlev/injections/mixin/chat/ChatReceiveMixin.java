package set.starlev.injections.mixin.chat;

import net.minecraft.class_2561;
import net.minecraft.class_634;
import net.minecraft.class_7438;
import net.minecraft.class_7439;
import net.minecraft.class_7827;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.features.chat.ChatEventsManager;
import set.starlev.features.overlays.NpcDialogueOverlay;

@Mixin(class_634.class)
public class ChatReceiveMixin {
    @Inject(method = "handleSystemChat", at = @At("HEAD"), cancellable = true)
    private void onReceiveChat(class_7439 packet, CallbackInfo ci) {
        class_2561 message = packet.comp_763();
        String messageText = message.getString();
        
        if (NpcDialogueOverlay.INSTANCE.onChat(message)) {
            ci.cancel();
            return;
        }
        
        if (!set.starlev.features.chat.MessageFilterManager.INSTANCE.shouldAllowMessage(messageText)) {
            ci.cancel();
            return;
        }
        
        ChatEventsManager.INSTANCE.onIncomingMessage(messageText);
    }

    @Inject(method = "handlePlayerChat", at = @At("HEAD"), cancellable = true)
    private void onReceivePlayerChat(class_7438 packet, CallbackInfo ci) {
        class_2561 message = packet.comp_1103();
        if (message == null) {
            return;
        }
        String messageText = message.getString();

        if (NpcDialogueOverlay.INSTANCE.onChat(message)) {
            ci.cancel();
            return;
        }

        if (!set.starlev.features.chat.MessageFilterManager.INSTANCE.shouldAllowMessage(messageText)) {
            ci.cancel();
            return;
        }

        ChatEventsManager.INSTANCE.onIncomingMessage(messageText);
    }

    @Inject(method = "handleDisguisedChat", at = @At("HEAD"), cancellable = true)
    private void onReceiveDisguisedChat(class_7827 packet, CallbackInfo ci) {
        class_2561 message = packet.comp_1097();
        String messageText = message.getString();

        if (NpcDialogueOverlay.INSTANCE.onChat(message)) {
            ci.cancel();
            return;
        }

        if (!set.starlev.features.chat.MessageFilterManager.INSTANCE.shouldAllowMessage(messageText)) {
            ci.cancel();
            return;
        }

        ChatEventsManager.INSTANCE.onIncomingMessage(messageText);
    }
}
