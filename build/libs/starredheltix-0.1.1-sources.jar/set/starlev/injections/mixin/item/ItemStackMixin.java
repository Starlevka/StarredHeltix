package set.starlev.injections.mixin.item;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starlev.secret.config.SecretMenuManager;
import set.starlev.secret.features.SecretFunFeatures;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import java.util.ArrayList;

@Mixin(class_1799.class)
public class ItemStackMixin {

    @Inject(method = "getHoverName", at = @At("RETURN"), cancellable = true)
    private void onGetHoverName(CallbackInfoReturnable<class_2561> cir) {
        if (!SecretMenuManager.INSTANCE.isConfigInitialized()) return;
        
        class_2561 original = cir.getReturnValue();
        if (original == null) return;
        
        // В предметах эффекты применяются всегда (force=true), если включены в конфиге
        class_2561 modified = SecretFunFeatures.processComponent(original, true);
        if (modified != original) {
            cir.setReturnValue(modified);
        }
    }

    @Inject(method = "getTooltipLines", at = @At("RETURN"), cancellable = true)
    private void onGetTooltipLines(net.minecraft.class_1792.class_9635 context, net.minecraft.class_1657 player, net.minecraft.class_1836 flag, CallbackInfoReturnable<List<class_2561>> cir) {
        if (!SecretMenuManager.INSTANCE.isConfigInitialized()) return;
        
        List<class_2561> original = cir.getReturnValue();
        if (original == null || original.isEmpty()) return;
        
        List<class_2561> modified = new ArrayList<>(original.size());
        boolean changed = false;
        
        for (class_2561 line : original) {
            // В предметах эффекты применяются всегда (force=true), если включены в конфиге
            class_2561 modLine = SecretFunFeatures.processComponent(line, true);
            if (modLine != line) {
                changed = true;
            }
            modified.add(modLine);
        }
        
        if (changed) {
            cir.setReturnValue(modified);
        }
    }
}
