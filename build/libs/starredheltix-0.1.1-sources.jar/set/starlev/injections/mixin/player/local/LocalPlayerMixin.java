package set.starlev.injections.mixin.player.local;

import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_746.class)
public abstract class LocalPlayerMixin {
}
