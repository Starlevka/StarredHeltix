package set.starlev.injections.mixin.player;

import net.minecraft.class_1657;
import net.minecraft.class_2561;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starlev.secret.config.SecretMenuManager;
import set.starlev.secret.features.SecretFunFeatures;

@Mixin(class_1657.class)
public abstract class PlayerMixin {
    private final java.util.Map<class_1657, class_2561> starred_cache = new java.util.WeakHashMap<>();

    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void onGetDisplayName(CallbackInfoReturnable<class_2561> cir) {
        if (!SecretMenuManager.INSTANCE.isConfigInitialized()) {
            return;
        }

        class_2561 original = cir.getReturnValue();
        if (original == null) return;

        class_1657 player = (class_1657) (Object) this;
        class_2561 cached = starred_cache.get(player);
        if (cached != null && cached.getString().equals(original.getString())) {
            cir.setReturnValue(cached);
            return;
        }

        // В отображаемых именах игроков эффекты применяются всегда (force=true), если включены в конфиге
        class_2561 modified = SecretFunFeatures.processComponent(original, true);
        if (modified != original) {
            starred_cache.put(player, modified);
            cir.setReturnValue(modified);
        }
    }
}
