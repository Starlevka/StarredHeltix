package set.starlev.injections.mixin.player;

import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starlev.StarredHeltix;
import set.starlev.features.visual.SwingAnimation;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends class_1297 {
    public LivingEntityMixin(class_1299<?> type, class_1937 level) {
        super(type, level);
    }

    @Inject(method = "die", at = @At("HEAD"))
    private void onDeath(class_1282 source, CallbackInfo ci) {
        if (StarredHeltix.Companion.getFeature().getOptimization().getVisualOptimizations().getHideDeathAnimation()) {
            this.method_31472();
        }
        set.starlev.utils.detectors.EntityDeathDetector.INSTANCE.onEntityDeath(this);
    }

    @Inject(method = "getCurrentSwingDuration", at = @At("RETURN"), cancellable = true)
    private void onGetCurrentSwingDuration(CallbackInfoReturnable<Integer> cir) {
        if (SwingAnimation.INSTANCE.isEnabled()) {
            class_310 mc = class_310.method_1551();
            if (mc.field_1724 != null && (Object)this == mc.field_1724) {
                int speed = SwingAnimation.INSTANCE.getSwingSpeed();
                if (speed > 0) {
                    cir.setReturnValue(speed);
                }
            }
        }
    }
}
