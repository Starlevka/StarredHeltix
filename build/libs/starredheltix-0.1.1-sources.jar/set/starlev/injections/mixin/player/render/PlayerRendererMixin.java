package set.starlev.injections.mixin.player.render;

import net.minecraft.class_1007;
import net.minecraft.class_2561;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import set.starlev.secret.config.SecretMenuManager;
import set.starlev.secret.features.SecretFunFeatures;

@Mixin(class_1007.class)
public abstract class PlayerRendererMixin {
    @org.spongepowered.asm.mixin.injection.ModifyArg(
        method = "submitNameTag", 
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/SubmitNodeCollector;submitNameTag(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/world/phys/Vec3;ILnet/minecraft/network/chat/Component;ZIDLnet/minecraft/client/renderer/state/CameraRenderState;)V"), 
        index = 3
    )
    private class_2561 onModifyNameTagArg(class_2561 component) {
        if (!SecretMenuManager.INSTANCE.isConfigInitialized()) {
            return component;
        }
        if (component == null) return null;
        // В именах над игроками эффекты применяются всегда (force=true), если включены в конфиге
        return SecretFunFeatures.processComponent(component, true);
    }
}
