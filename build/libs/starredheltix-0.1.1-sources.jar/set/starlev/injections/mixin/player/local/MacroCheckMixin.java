package set.starlev.injections.mixin.player.local;

import net.minecraft.class_10185;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.features.chat.mod.MacroCheck;

@Mixin(class_746.class)
public abstract class MacroCheckMixin {
    @Inject(method = "aiStep", at = @At("HEAD"))
    private void onAiStep(CallbackInfo ci) {
        if (MacroCheck.INSTANCE.isBlocked()) {
            class_746 player = (class_746) (Object) this;
            // Блокируем только ввод движения, не трогая гравитацию
            player.field_3913.field_54155 = new class_10185(
                false, // forward
                false, // backward
                false, // left
                false, // right
                false, // jump
                false, // shift
                player.field_3913.field_54155.comp_3165() // sprint оставляем как есть
            );
        }
    }
}
