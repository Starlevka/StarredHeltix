package set.starlev.injections.mixin.input;

import net.minecraft.class_11910;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.features.mining.AutoCommissions;

/**
    * Перехватывает ПКМ для авто-поручений:
    * блокирует реальный клик и переключает слот на Королевского голубя.
    */
@Mixin(class_312.class)
public class MouseButtonMixin {

    @Inject(method = "onButton", at = @At("HEAD"), cancellable = true)
    private void onButton(long window, class_11910 mouseButtonInfo, int action, CallbackInfo ci) {
        // ПКМ нажат (button 1, action 1 = pressed)
        if (mouseButtonInfo.comp_4801() == 1 && action == 1) {
            if (AutoCommissions.INSTANCE.isWaitingForClick()) {
                AutoCommissions.INSTANCE.onRightClickWhileWaiting();
                ci.cancel();
            }
        }
    }
}