package set.starlev.injections.mixin.optimization;

import set.starlev.utils.IWorldRenderer;
import set.starlev.StarredHeltix;
import net.minecraft.class_11944;
import net.minecraft.class_310;
import net.minecraft.class_3940;
import net.minecraft.class_4184;
import net.minecraft.class_4604;
import net.minecraft.class_703;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3940.class)
public abstract class ParticleCullingMixin {

    // Кэшируем ссылку на IWorldRenderer — lookup только при смене уровня
    @org.spongepowered.asm.mixin.Unique
    private static IWorldRenderer starredheltix$cachedWorldRenderer;

    @org.spongepowered.asm.mixin.Unique
    private static class_761 starredheltix$lastLevelRenderer;

    @Inject(method = "extract", at = @At("HEAD"), cancellable = true)
    private void onExtract(class_11944 quadParticleRenderState, class_4184 camera, float f, CallbackInfo ci) {
        // Проверка конфига
        try {
            if (!StarredHeltix.Companion.getFeature().getOptimization().getRenderOptimizations().getParticleCulling()) return;
        } catch (Throwable ignored) { return; }

        // Быстрая проверка кэша без instanceof каждый вызов
        class_761 currentRenderer = class_310.method_1551().field_1769;
        if (currentRenderer != starredheltix$lastLevelRenderer) {
            starredheltix$lastLevelRenderer = currentRenderer;
            starredheltix$cachedWorldRenderer = (currentRenderer instanceof IWorldRenderer) ? (IWorldRenderer) currentRenderer : null;
        }

        if (starredheltix$cachedWorldRenderer == null) return;

        class_4604 frustum = starredheltix$cachedWorldRenderer.starredheltix$getFrustum();
        if (frustum == null) return;

        class_703 particle = (class_703) (Object) this;
        if (!frustum.method_23093(particle.method_3064())) {
            ci.cancel();
        }
    }
}
