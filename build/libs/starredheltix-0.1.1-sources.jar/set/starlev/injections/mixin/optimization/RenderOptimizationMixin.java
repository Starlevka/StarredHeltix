package set.starlev.injections.mixin.optimization;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_243;
import net.minecraft.class_4604;
import net.minecraft.class_761;
import net.minecraft.class_9909;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.utils.IWorldRenderer;
import set.starlev.StarredHeltix;

@Environment(EnvType.CLIENT)
@Mixin(class_761.class)
public class RenderOptimizationMixin {
    @Inject(method = "applyFrustum", at = @At("HEAD"))
    private void onApplyFrustum(class_4604 frustum, CallbackInfo ci) {
        if ((Object) this instanceof IWorldRenderer worldRenderer) {
            worldRenderer.starredheltix$setFrustum(frustum);
        }
    }

    @Inject(method = "addWeatherPass", at = @At("HEAD"), cancellable = true)
    private void optimizeWeather(class_9909 frameGraphBuilder, class_243 vec3, GpuBufferSlice gpuBufferSlice, CallbackInfo ci) {
        try {
            if (StarredHeltix.Companion.getFeature().getOptimization().getRenderOptimizations().getWeatherOptimization()) {
                ci.cancel();
            }
        } catch (Throwable ignored) {
        }
    }
}
