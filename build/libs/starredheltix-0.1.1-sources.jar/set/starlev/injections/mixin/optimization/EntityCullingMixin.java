package set.starlev.injections.mixin.optimization;

import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_310;
import net.minecraft.class_4604;
import net.minecraft.class_761;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starlev.StarredHeltix;
import set.starlev.utils.IWorldRenderer;

@Mixin(class_898.class)
public class EntityCullingMixin {

    @org.spongepowered.asm.mixin.Unique
    private static IWorldRenderer starredheltix$cachedWorldRenderer;

    @org.spongepowered.asm.mixin.Unique
    private static class_761 starredheltix$lastLevelRenderer;

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private <E extends class_1297> void onShouldRender(E entity, class_4604 frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
        try {
            if (!StarredHeltix.Companion.getFeature().getOptimization().getRenderOptimizations().getEntityCulling()) return;
        } catch (Throwable ignored) { return; }

        // Пропускаем игрока — он всегда должен рендериться от третьего лица
        if (entity == class_310.method_1551().field_1724) return;

        // Быстрая проверка кэша без instanceof каждый вызов
        class_761 currentRenderer = class_310.method_1551().field_1769;
        if (currentRenderer != starredheltix$lastLevelRenderer) {
            starredheltix$lastLevelRenderer = currentRenderer;
            starredheltix$cachedWorldRenderer = (currentRenderer instanceof IWorldRenderer) ? (IWorldRenderer) currentRenderer : null;
        }

        if (starredheltix$cachedWorldRenderer == null) return;

        class_4604 cachedFrustum = starredheltix$cachedWorldRenderer.starredheltix$getFrustum();
        if (cachedFrustum == null) return;

        // Проверяем AABB сущности через frustum
        try {
            class_238 box = entity.method_5829();
            if (!cachedFrustum.method_23093(box)) {
                cir.setReturnValue(false);
            }
        } catch (Exception ignored) {}
    }
}