package set.starlev.injections.mixin.optimization;

import net.minecraft.class_11659;
import net.minecraft.class_11954;
import net.minecraft.class_12075;
import net.minecraft.class_238;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4604;
import net.minecraft.class_761;
import net.minecraft.class_824;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.utils.IWorldRenderer;
import set.starlev.StarredHeltix;

@Mixin(class_824.class)
public abstract class BlockEntityCullingMixin {
    @org.spongepowered.asm.mixin.Shadow
    public abstract <E extends net.minecraft.class_2586, S extends class_11954> net.minecraft.class_827<E, S> getRenderer(S state);

    // Кэшируем ссылку на IWorldRenderer — обновляется только при смене уровня
    @org.spongepowered.asm.mixin.Unique
    private static IWorldRenderer starredheltix$cachedWorldRenderer;

    @org.spongepowered.asm.mixin.Unique
    private static class_761 starredheltix$lastLevelRenderer;

    @Inject(method = "submit", at = @At("HEAD"), cancellable = true)
    private void onRender(class_11954 state, class_4587 poseStack, class_11659 collector, class_12075 cameraState, CallbackInfo ci) {
        // Проверка конфига
        try {
            if (!StarredHeltix.Companion.getFeature().getOptimization().getRenderOptimizations().getBlockEntityCulling()) return;
        } catch (Throwable ignored) { return; }

        // Пропускаем "глобальные" блочные сущности, которые должны быть видны издалека (например, маяки)
        net.minecraft.class_827<?, ?> renderer = getRenderer(state);
        if (renderer != null && renderer.method_3563()) {
            return;
        }

        // Быстрая проверка кэша без instanceof каждый вызов
        class_761 currentRenderer = class_310.method_1551().field_1769;
        if (currentRenderer != starredheltix$lastLevelRenderer) {
            starredheltix$lastLevelRenderer = currentRenderer;
            starredheltix$cachedWorldRenderer = (currentRenderer instanceof IWorldRenderer) ? (IWorldRenderer) currentRenderer : null;
        }

        if (starredheltix$cachedWorldRenderer == null) return;

        class_4604 frustum = starredheltix$cachedWorldRenderer.starredheltix$getFrustum();
        if (frustum == null || state.field_62673 == null) return;

        // AABB — immutable (поля final), создаём новый, но lookup frustum кэширован
        class_238 box = new class_238(state.field_62673);
        if (!frustum.method_23093(box)) {
            ci.cancel();
        }
    }
}
