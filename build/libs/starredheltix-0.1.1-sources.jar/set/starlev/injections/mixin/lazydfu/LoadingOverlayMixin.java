package set.starlev.injections.mixin.lazydfu;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4011;
import net.minecraft.class_425;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starlev.config.ConfigManager;

/**
 * Убирает задержку и анимацию fade-out на загрузочном экране.
 * Загрузочный экран исчезает мгновенно после завершения загрузки ресурсов.
 *
 * Исходный код: https://github.com/GUN2RAS/FastBoot
 */
@Mixin(class_425.class)
public class LoadingOverlayMixin {

    @Shadow private class_4011 reload;
    @Shadow private long fadeOutStart;

    @Inject(method = "isReadyToFadeOut", at = @At("HEAD"), cancellable = true)
    private void skipGracePeriod(CallbackInfoReturnable<Boolean> cir) {
        if (ConfigManager.INSTANCE.getFeaturesSafe().getOptimization().getFastBoot().enabled && ConfigManager.INSTANCE.getFeaturesSafe().getOptimization().getFastBoot().skipFadeAnimations) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void skipFadeOut(class_332 context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
        if (ConfigManager.INSTANCE.getFeaturesSafe().getOptimization().getFastBoot().enabled && ConfigManager.INSTANCE.getFeaturesSafe().getOptimization().getFastBoot().skipFadeAnimations) {
            if (this.reload != null && fadeOutStart > -1L) {
                class_310.method_1551().method_18502(null);
            }
        }
    }
}
