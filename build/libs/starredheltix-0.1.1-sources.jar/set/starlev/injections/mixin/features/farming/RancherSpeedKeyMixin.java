package set.starlev.injections.mixin.features.farming;

import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_437.class)
public class RancherSpeedKeyMixin {
}
