package set.starlev.injections.mixin.features.skyblock;

import net.minecraft.class_243;
import net.minecraft.class_2708;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.features.skyblock.SmoothAote;

@Mixin(class_634.class)
public class SmoothAoteMixin {
    private class_243 starredheltix$preMoveCameraPos;

    @Inject(method = "handleMovePlayer", at = @At("HEAD"))
    private void onHandleMovePlayerHead(class_2708 packet, CallbackInfo ci) {
        this.starredheltix$preMoveCameraPos = class_310.method_1551().field_1773.method_19418().method_19326();
    }

    @Inject(method = "handleMovePlayer", at = @At("RETURN"))
    private void onHandleMovePlayer(class_2708 packet, CallbackInfo ci) {
        if (class_310.method_1551().field_1724 != null) {
            class_243 pre = this.starredheltix$preMoveCameraPos;
            class_243 post = class_310.method_1551().field_1724.method_73189();
            if (pre != null) {
                SmoothAote.INSTANCE.onTeleport(pre, post);
            } else {
                SmoothAote.INSTANCE.onTeleport(post);
            }
        }
    }
}
