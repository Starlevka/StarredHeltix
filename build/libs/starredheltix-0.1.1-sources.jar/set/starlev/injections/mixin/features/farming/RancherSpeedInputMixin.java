package set.starlev.injections.mixin.features.farming;

import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_4069;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starlev.features.farming.RancherSpeedHud;

@Mixin(class_4069.class)
public interface RancherSpeedInputMixin {
    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void starredheltix$mouseClicked(class_11909 event, boolean isDoubleClick, CallbackInfoReturnable<Boolean> cir) {
        if (RancherSpeedHud.onMouseClicked(event)) {
            cir.setReturnValue(true);
            cir.cancel();
        }
    }

    @Inject(method = "charTyped", at = @At("HEAD"), cancellable = true)
    private void starredheltix$charTyped(class_11905 event, CallbackInfoReturnable<Boolean> cir) {
        if (RancherSpeedHud.onCharTyped(event)) {
            cir.setReturnValue(true);
            cir.cancel();
        }
    }

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void starredheltix$keyPressed(class_11908 event, CallbackInfoReturnable<Boolean> cir) {
        if (RancherSpeedHud.onKeyPressed(event)) {
            cir.setReturnValue(true);
            cir.cancel();
        }
    }
}
