package set.starlev.injections.mixin.minecraft;

import net.minecraft.class_310;
import net.minecraft.class_433;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.config.ConfigManager;
import set.starlev.features.overlays.NpcDialogueOverlay;

@Mixin(class_310.class)
public class MinecraftPauseScreenMixin {
    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void onSetScreen(class_437 screen, CallbackInfo ci) {
        if (screen instanceof class_433) {
            // Check if NPC Dialogue Overlay is active and Close on ESC is enabled
            if (ConfigManager.INSTANCE.getFeatures().getSkyblock().getNpcDialogue().getCloseOnEsc()) {
                if (NpcDialogueOverlay.INSTANCE.isActive()) {
                    NpcDialogueOverlay.INSTANCE.close();
                    ci.cancel(); // Prevent PauseScreen from opening
                }
            }
        }
    }
}
