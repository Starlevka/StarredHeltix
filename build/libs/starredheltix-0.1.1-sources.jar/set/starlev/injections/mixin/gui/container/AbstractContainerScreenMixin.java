package set.starlev.injections.mixin.gui.container;

import net.minecraft.class_11909;
import net.minecraft.class_332;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starlev.events.GuiEvents;
import set.starlev.render.RenderEngine;

@Mixin(class_465.class)
public abstract class AbstractContainerScreenMixin {
    private boolean starredheltix$isStarlevScreen() {
        return ((Object) this).getClass().getName().startsWith("set.starlev.");
    }

    @Inject(method = "init", at = @At("RETURN"))
    private void onInit(CallbackInfo ci) {
        GuiEvents.fireOpen((class_465<?>) (Object) this);
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void onRenderHead(class_332 graphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!starredheltix$isStarlevScreen()) {
            GuiEvents.fireRender(graphics);
            RenderEngine.renderHud(graphics, delta);
        }
        if (starredheltix$isStarlevScreen()) {
            RenderEngine.renderHud(graphics, delta);
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void onRenderTail(class_332 graphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!starredheltix$isStarlevScreen()) {
            GuiEvents.fireForeground(graphics, mouseX, mouseY, (class_465<?>) (Object) this);
        }
        if (starredheltix$isStarlevScreen()) {
            GuiEvents.fireRender(graphics);
        }
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void onMouseClicked(class_11909 event, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
        if (!starredheltix$isStarlevScreen()) {
            if (GuiEvents.fireClick(event.comp_4798(), event.comp_4799(), event.method_74245(), (class_465<?>) (Object) this)) {
                cir.setReturnValue(true);
            }
        }
    }

    @Inject(method = "removed", at = @At("HEAD"))
    private void onRemoved(CallbackInfo ci) {
        GuiEvents.fireClose((class_465<?>) (Object) this);
    }
}
