package set.starlev.injections.mixin.gui.tab;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starlev.secret.features.SecretFunFeatures;

import set.starlev.secret.config.SecretMenuManager;

import java.util.WeakHashMap;
import net.minecraft.class_2561;
import net.minecraft.class_355;
import net.minecraft.class_640;
import java.util.Map;

@Mixin(class_355.class)
public class PlayerTabOverlayMixin {
    private final Map<class_640, class_2561> starred_cache = new WeakHashMap<>();

    @Inject(method = "getNameForDisplay", at = @At("RETURN"), cancellable = true)
    private void onGetNameForDisplay(class_640 playerInfo, CallbackInfoReturnable<class_2561> cir) {
        if (!SecretMenuManager.INSTANCE.isConfigInitialized()) return;
        
        class_2561 original = cir.getReturnValue();
        if (original == null) return;

        // Используем кэш специфичный для PlayerInfo, чтобы избежать дёрганья
        class_2561 cached = starred_cache.get(playerInfo);
        if (cached != null && cached.getString().equals(original.getString())) {
            cir.setReturnValue(cached);
            return;
        }

        class_2561 modified = SecretFunFeatures.processComponent(original, true);
        if (modified != original) {
            starred_cache.put(playerInfo, modified);
            cir.setReturnValue(modified);
        }
    }
}
