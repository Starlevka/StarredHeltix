package set.starlev.injections.mixin.gui;

import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.render.RenderEngine;

@Mixin(class_437.class)
public class ScreenMixin {
    @Inject(method = "render", at = @At("HEAD"))
    private void onRenderHead(class_332 graphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!((Object) this instanceof class_465)) {
            RenderEngine.renderHud(graphics, delta);
        }
    }
}
