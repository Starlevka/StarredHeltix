package set.starlev.injections.mixin.gui;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import set.starlev.secret.config.SecretMenuManager;
import set.starlev.secret.features.SecretFunFeatures;

@Mixin(class_332.class)
public class GuiGraphicsMixin {
    private static boolean starredheltix$isSecretMenuOpen() {
        try {
            net.minecraft.class_437 screen = class_310.method_1551().field_1755;
            if (screen == null) return false;
            return screen.getClass().getName().equals("io.github.notenoughupdates.moulconfig.platform.MoulConfigScreenComponent");
        } catch (Exception e) {
            return false;
        }
    }
    
    @ModifyVariable(
        method = "drawString(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;IIIZ)V",
        at = @At("HEAD"),
        argsOnly = true
    )
    private class_2561 onDrawString(class_2561 component) {
        if (component == null) return null;
        if (!SecretMenuManager.INSTANCE.isConfigInitialized()) return component;
        
        boolean force = starredheltix$isSecretMenuOpen();
        return SecretFunFeatures.processComponent(component, force);
    }

    @ModifyVariable(
        method = "drawCenteredString(Lnet/minecraft/client/gui/Font;Lnet/minecraft/network/chat/Component;III)V",
        at = @At("HEAD"),
        argsOnly = true
    )
    private class_2561 onDrawCenteredString(class_2561 component) {
        if (component == null) return null;
        if (!SecretMenuManager.INSTANCE.isConfigInitialized()) return component;
        
        boolean force = starredheltix$isSecretMenuOpen();
        return SecretFunFeatures.processComponent(component, force);
    }

    @ModifyVariable(
        method = "drawString(Lnet/minecraft/client/gui/Font;Ljava/lang/String;IIIZ)V",
        at = @At("HEAD"),
        argsOnly = true
    )
    private String onDrawString(String text) {
        if (text == null) return null;
        if (!SecretMenuManager.INSTANCE.isConfigInitialized()) return text;
        
        class_2561 component = class_2561.method_43470(text);
        boolean force = starredheltix$isSecretMenuOpen();
        class_2561 processed = SecretFunFeatures.processComponent(component, force);
        
        if (processed != component) {
            return set.starlev.utils.detectors.TabListDetector.componentToFormattedString(processed);
        }
        
        return text;
    }

    @ModifyVariable(
        method = "drawCenteredString(Lnet/minecraft/client/gui/Font;Ljava/lang/String;III)V",
        at = @At("HEAD"),
        argsOnly = true
    )
    private String onDrawCenteredString(String text) {
        if (text == null) return null;
        if (!SecretMenuManager.INSTANCE.isConfigInitialized()) return text;
        
        class_2561 component = class_2561.method_43470(text);
        boolean force = starredheltix$isSecretMenuOpen();
        class_2561 processed = SecretFunFeatures.processComponent(component, force);
        
        if (processed != component) {
            return set.starlev.utils.detectors.TabListDetector.componentToFormattedString(processed);
        }
        
        return text;
    }

    @ModifyVariable(
        method = "setTooltipForNextFrame(Lnet/minecraft/client/gui/Font;Ljava/util/List;Ljava/util/Optional;II)V",
        at = @At("HEAD"),
        argsOnly = true
    )
    private java.util.List<net.minecraft.class_2561> onRenderTooltip(java.util.List<net.minecraft.class_2561> lines) {
        if (lines == null || !SecretMenuManager.INSTANCE.isConfigInitialized()) return lines;
        
        java.util.List<net.minecraft.class_2561> processed = new java.util.ArrayList<>(lines.size());
        boolean force = starredheltix$isSecretMenuOpen();
        for (net.minecraft.class_2561 line : lines) {
            processed.add(SecretFunFeatures.processComponent(line, force));
        }
        return processed;
    }
}
