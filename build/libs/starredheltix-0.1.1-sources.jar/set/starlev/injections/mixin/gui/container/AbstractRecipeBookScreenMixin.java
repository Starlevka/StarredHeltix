package set.starlev.injections.mixin.gui.container;

import net.minecraft.class_10260;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.events.GuiEvents;

@Mixin(class_10260.class)
public abstract class AbstractRecipeBookScreenMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void onRenderTail(class_332 graphics, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!((Object) this).getClass().getName().startsWith("set.starlev.")) {
            GuiEvents.fireForeground(graphics, mouseX, mouseY, (net.minecraft.class_465<?>) (Object) this);
        }
    }
}