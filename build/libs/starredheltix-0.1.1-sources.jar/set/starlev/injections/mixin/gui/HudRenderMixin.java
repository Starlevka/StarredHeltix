package set.starlev.injections.mixin.gui;

import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.render.RenderEngine;

@Mixin(class_329.class)
public class HudRenderMixin {
    @Inject(method = "render", at = @At("RETURN"))
    private void onRenderHud(class_332 graphics, class_9779 delta, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1755 == null && !mc.field_1690.field_1842) {
            RenderEngine.renderHud(graphics, delta.method_60637(false));
        }
    }
}
