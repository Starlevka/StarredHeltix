package set.starlev.injections.mixin.sounds;

import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_1144;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starlev.StarredHeltix;

@Mixin(value = class_1144.class, priority = 1000)
public class SoundEngineMixin {

    @Inject(method = "play(Lnet/minecraft/client/resources/sounds/SoundInstance;)Lnet/minecraft/client/sounds/SoundEngine$PlayResult;", at = @At("HEAD"), cancellable = true)
    private void onPlay(class_1113 sound, CallbackInfoReturnable<class_1140.class_11518> cir) {
        if (!StarredHeltix.getFeature().getMusic().getDisableExplosionSounds()) return;

        String path = sound.method_4775().method_12832();
        if (path.contains("explode") || path.contains("tnt") || path.contains("explosion")) {
            cir.setReturnValue(class_1140.class_11518.field_60956);
        }
    }
}