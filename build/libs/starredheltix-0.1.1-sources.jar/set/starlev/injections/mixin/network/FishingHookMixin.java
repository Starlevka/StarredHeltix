package set.starlev.injections.mixin.network;

import net.minecraft.class_1536;
import net.minecraft.class_2940;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.features.fishing.FishingNotifier;

@Mixin(class_1536.class)
public class FishingHookMixin {
    @Shadow
    @Final
    private static class_2940<Boolean> DATA_BITING;

    private boolean starredheltix$wasBiting;

    @Inject(method = "onSyncedDataUpdated", at = @At("TAIL"))
    private void starredheltix$onSyncedDataUpdated(class_2940<?> accessor, CallbackInfo ci) {
        if (accessor != DATA_BITING) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        class_1536 hook = client.field_1724.field_7513;
        if (hook == null) return;

        if ((Object) this != hook) return;

        boolean isBiting = hook.method_5841().method_12789(DATA_BITING);
        if (isBiting && !starredheltix$wasBiting) FishingNotifier.INSTANCE.onBite();
        starredheltix$wasBiting = isBiting;
    }
}
