package set.starlev.injections.mixin.render.sky;

import net.minecraft.class_12076;
import net.minecraft.class_243;
import net.minecraft.class_638;
import net.minecraft.class_9975;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_9975.class)
public class SkyRendererMixin {

    @Inject(method = "extractRenderState", at = @At("RETURN"))
    private void onExtractRenderState(class_638 level, float partialTick, class_243 cameraPos, class_12076 state, CallbackInfo ci) {
        // Custom weather and other visual features can be handled here if needed
    }
}
