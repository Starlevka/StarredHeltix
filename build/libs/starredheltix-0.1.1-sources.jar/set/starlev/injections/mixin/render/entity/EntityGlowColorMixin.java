package set.starlev.injections.mixin.render.entity;

import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starlev.features.combat.EntityHighlight;

@Mixin(class_1297.class)
public class EntityGlowColorMixin {
    @Inject(method = "isCurrentlyGlowing", at = @At("RETURN"), cancellable = true)
    private void starredheltix$forceClientGlow(CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValue()) return;
        class_1297 entity = (class_1297) (Object) this;
        int id = entity.method_5628();
        if (EntityHighlight.getGlowColor(id) != -1) {
            net.minecraft.class_310 mc = net.minecraft.class_310.method_1551();
            if (mc.field_1724 != null && mc.field_1724 != entity && !mc.field_1724.method_6057(entity)) {
                return;
            }
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "getTeamColor", at = @At("RETURN"), cancellable = true)
    private void starredheltix$overrideGlowColor(CallbackInfoReturnable<Integer> cir) {
        int id = ((class_1297) (Object) this).method_5628();
        int color = EntityHighlight.getGlowColor(id);
        if (color != -1) {
            cir.setReturnValue(color);
        }
    }
}
