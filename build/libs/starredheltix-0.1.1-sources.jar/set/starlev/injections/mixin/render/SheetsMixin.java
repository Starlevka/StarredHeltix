package set.starlev.injections.mixin.render;

import net.minecraft.class_11959;
import net.minecraft.class_2745;
import net.minecraft.class_2960;
import net.minecraft.class_4722;
import net.minecraft.class_4730;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starlev.StarredHeltix;
import set.starlev.utils.detectors.DungeonDetector;

@Mixin(class_4722.class)
public class SheetsMixin {
    private static class_4730 GREEN_CHEST_MATERIAL;

    @Inject(method = "chooseMaterial(Lnet/minecraft/client/renderer/blockentity/state/ChestRenderState$ChestMaterialType;Lnet/minecraft/world/level/block/state/properties/ChestType;)Lnet/minecraft/client/resources/model/Material;", at = @At("HEAD"), cancellable = true)
    private static void onChestMaterial(class_11959.class_11960 materialType, class_2745 type, CallbackInfoReturnable<class_4730> cir) {
        if (StarredHeltix.Companion.getFeature().getDungeons().getVisuals().getGreenChests() && DungeonDetector.INSTANCE.isInDungeon()) {
            // Для обычных и ловушечных сундуков используем зеленую текстуру
            if (materialType == class_11959.class_11960.field_62704 || materialType == class_11959.class_11960.field_62699) {
                if (GREEN_CHEST_MATERIAL == null) {
                    // Используем тот же атлас, что и для обычных сундуков
                    GREEN_CHEST_MATERIAL = new class_4730(class_4722.field_21709, class_2960.method_60656("entity/chest/green_chest"));
                }
                cir.setReturnValue(GREEN_CHEST_MATERIAL);
            }
        }
    }
}
