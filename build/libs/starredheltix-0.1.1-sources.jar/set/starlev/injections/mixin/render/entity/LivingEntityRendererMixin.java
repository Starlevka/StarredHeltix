package set.starlev.injections.mixin.render.entity;

import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.secret.features.SecretFunFeatures;

@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin {

    @Inject(method = "setupRotations", at = @At("HEAD"))
    private void onSetupRotations(class_10042 state, class_4587 poseStack, float f, float g, CallbackInfo ci) {
        if (!SecretFunFeatures.INSTANCE.isFlipEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        // AvatarRenderState имеет публичное поле id — рефлексия не нужна
        if (state instanceof class_10055 avatarState && avatarState.field_53528 == mc.field_1724.method_5628()) {
            poseStack.method_22904(0.0D, state.field_53330 + 0.1F, 0.0D);
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
        }
    }
}
