package set.starlev.injections.mixin.render.camera;

import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.features.skyblock.SmoothAote;

@Mixin(class_4184.class)
public abstract class CameraMixin {

    @Shadow
    protected abstract void setPosition(double x, double y, double z);

    @Shadow
    public abstract class_243 getPosition();

    @Inject(method = "setup", at = @At("RETURN"))
    private void onSetup(class_1922 level, class_1297 entity, boolean detached, boolean thirdPerson, float partialTick, CallbackInfo ci) {
        class_243 offset = SmoothAote.INSTANCE.getOffset();
        if (offset != null) {
            class_243 current = this.getPosition();
            this.setPosition(current.field_1352 + offset.field_1352, current.field_1351 + offset.field_1351, current.field_1350 + offset.field_1350);
        }
    }
}
