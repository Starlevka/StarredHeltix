package set.starlev.injections.mixin.render.level;

import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Coerce;
import set.starlev.features.visual.BlockOverlayFeature;

@Mixin(class_761.class)
public class BlockOverlayMixin {

    @Inject(method = "renderHitOutline", at = @At("HEAD"), cancellable = true)
    private void onRenderHitOutline(class_4587 poseStack, class_4588 vertexConsumer, double x, double y, double z, @Coerce Object shape, int color, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        class_239 hitResult = mc.field_1765;
        
        if (hitResult instanceof class_3965 blockHitResult) {
            class_2338 blockPos = blockHitResult.method_17777();
            class_2680 blockState = mc.field_1687.method_8320(blockPos);
            class_1297 entity = mc.method_1560();
            
            if (entity != null && BlockOverlayFeature.INSTANCE.onRenderBlockOverlay(poseStack, entity, x, y, z, blockPos, blockState)) {
                ci.cancel();
            }
        }
    }
}
