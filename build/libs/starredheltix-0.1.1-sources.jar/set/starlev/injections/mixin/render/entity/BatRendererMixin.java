package set.starlev.injections.mixin.render.entity;

import net.minecraft.class_10001;
import net.minecraft.class_2960;
import net.minecraft.class_879;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starlev.StarredHeltix;
import set.starlev.utils.detectors.DungeonDetector;

@Mixin(class_879.class)
public class BatRendererMixin {
    private static final class_2960 GREEN_BAT_LOCATION = class_2960.method_60655("starredheltix", "textures/entity/green_bat.png");

    @Inject(method = "getTextureLocation", at = @At("HEAD"), cancellable = true)
    private void onGetTextureLocation(class_10001 state, CallbackInfoReturnable<class_2960> cir) {
        if (StarredHeltix.Companion.getFeature().getDungeons().getVisuals().getGreenBats() && DungeonDetector.INSTANCE.isInDungeon()) {
            cir.setReturnValue(GREEN_BAT_LOCATION);
        }
    }
}
