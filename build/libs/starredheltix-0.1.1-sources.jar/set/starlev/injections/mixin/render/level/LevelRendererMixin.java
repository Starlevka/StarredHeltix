package set.starlev.injections.mixin.render.level;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.minecraft.class_11658;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4604;
import net.minecraft.class_761;
import net.minecraft.class_9925;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starlev.render.RenderContext;
import set.starlev.render.RenderEvents;

@Mixin(class_761.class)
public class LevelRendererMixin implements set.starlev.utils.IWorldRenderer {
    @Shadow @Final private net.minecraft.class_4599 renderBuffers;

    @org.spongepowered.asm.mixin.Unique
    public net.minecraft.class_4604 starredheltix$capturedFrustum;

    @Override
    public net.minecraft.class_4604 starredheltix$getFrustum() {
        return starredheltix$capturedFrustum;
    }

    @Override
    public void starredheltix$setFrustum(class_4604 frustum) {
        this.starredheltix$capturedFrustum = frustum;
    }

    @org.spongepowered.asm.mixin.Unique
    private final class_4587 starredheltix$reusablePoseStack = new class_4587();

    @Inject(method = "method_62214", at = @At("HEAD"))
    private void onRenderWorldHead(GpuBufferSlice gpuBufferSlice, class_11658 worldRenderState, net.minecraft.class_3695 profiler, Matrix4f matrix4f, class_9925 handle, class_9925 handle2, boolean bl, net.minecraft.class_4604 frustum, class_9925 handle3, class_9925 handle4, CallbackInfo ci) {
        this.starredheltix$capturedFrustum = frustum;
    }

    @Inject(method = "method_62214", at = @At("RETURN"))
    private void onRenderWorld(GpuBufferSlice gpuBufferSlice, class_11658 worldRenderState, net.minecraft.class_3695 profiler, Matrix4f matrix4f, class_9925 handle, class_9925 handle2, boolean bl, net.minecraft.class_4604 frustum, class_9925 handle3, class_9925 handle4, CallbackInfo ci) {
        net.minecraft.class_310 mc = net.minecraft.class_310.method_1551();
        class_4184 camera = mc.field_1773.method_19418();
        class_4597.class_4598 bufferSource = this.renderBuffers.method_23000();

        // Переиспользуем PoseStack вместо создания нового каждый кадр
        class_4587 poseStack = this.starredheltix$reusablePoseStack;
        // Сбрасываем трансформации перед использованием
        poseStack.method_34426();

        RenderContext context = new RenderContext(
            poseStack, 
            camera, 
            mc.method_61966().method_60636(), 
            bufferSource,
            worldRenderState.field_63082
        );

        RenderEvents.fireWorldRender(context);

        poseStack.method_22903();
        set.starlev.render.RenderEngine.renderWorld(poseStack, bufferSource, mc.method_61966().method_60636());
        poseStack.method_22909();

        // Флешим только необходимые буферы (lightning и debugQuads для ESP)
        // endBatch() без аргументов флешит все оставшиеся, поэтому отдельные вызовы избыточны
        bufferSource.method_22994(net.minecraft.class_1921.method_23593());
        bufferSource.method_22994(net.minecraft.class_1921.method_49042());
        bufferSource.method_22993();
    }
}
