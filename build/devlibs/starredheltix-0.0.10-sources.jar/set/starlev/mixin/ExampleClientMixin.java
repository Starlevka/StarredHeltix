package set.starlev.mixin;

import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class ExampleClientMixin {
	@Inject(at = @At("HEAD"), method = "run")
	private void init(CallbackInfo info) {
		// This code is injected into the start of MinecraftClient.run()V
	}

	@Inject(at = @At("TAIL"), method = "setLevel")
	private void onWorldJoin(CallbackInfo info) {
		set.starlev.features.misc.VotingReminder.INSTANCE.checkAndShowReminder();
	}
}